package imdb.entity;

import javax.persistence.*;

@Entity
@Table(name = "films")
public class Film {
	//TODO: Implement me ...
}
