package imdb.bindingModel;

public class FilmBindingModel {
	//TODO: Implement me ...
}
