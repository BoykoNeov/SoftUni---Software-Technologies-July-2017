<?php

/* film/edit.html.twig */
class __TwigTemplate_f95d725639f60feb56a914417ea3d7b3f300f22b85dcbdd4b83a5a792c89f99b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "film/edit.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6f99d1ae00635c6aa66c3b31963bd9ab471ac7d0420fad4e22daccef84149c38 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6f99d1ae00635c6aa66c3b31963bd9ab471ac7d0420fad4e22daccef84149c38->enter($__internal_6f99d1ae00635c6aa66c3b31963bd9ab471ac7d0420fad4e22daccef84149c38_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "film/edit.html.twig"));

        $__internal_5124ac65390a302b27529167e87d382f468d1d41986ce9547b4f4d71cf17a7d0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5124ac65390a302b27529167e87d382f468d1d41986ce9547b4f4d71cf17a7d0->enter($__internal_5124ac65390a302b27529167e87d382f468d1d41986ce9547b4f4d71cf17a7d0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "film/edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6f99d1ae00635c6aa66c3b31963bd9ab471ac7d0420fad4e22daccef84149c38->leave($__internal_6f99d1ae00635c6aa66c3b31963bd9ab471ac7d0420fad4e22daccef84149c38_prof);

        
        $__internal_5124ac65390a302b27529167e87d382f468d1d41986ce9547b4f4d71cf17a7d0->leave($__internal_5124ac65390a302b27529167e87d382f468d1d41986ce9547b4f4d71cf17a7d0_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_b3f94bc7f3afa5406f35607378f931df73ea65dfcc415b52cb68ffdcd2f5a57c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b3f94bc7f3afa5406f35607378f931df73ea65dfcc415b52cb68ffdcd2f5a57c->enter($__internal_b3f94bc7f3afa5406f35607378f931df73ea65dfcc415b52cb68ffdcd2f5a57c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_647109de8645dba3d740e006229c10b9b5577311187bf4317e925d88989b29ca = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_647109de8645dba3d740e006229c10b9b5577311187bf4317e925d88989b29ca->enter($__internal_647109de8645dba3d740e006229c10b9b5577311187bf4317e925d88989b29ca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "    <h1>Edit Film</h1>
    <section>
        <form method=\"POST\">
            <div>
                <label for=\"name\">Name</label>
                <input type=\"text\" id=\"name\" value=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute(($context["film"] ?? $this->getContext($context, "film")), "name", array()), "html", null, true);
        echo "\" name=\"film[name]\" />
                <label for=\"genre\">Genre</label>
                <input type=\"text\" id=\"genre\" value=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->getAttribute(($context["film"] ?? $this->getContext($context, "film")), "genre", array()), "html", null, true);
        echo "\" name=\"film[genre]\" />
                <label for=\"director\">Director</label>
                <input type=\"text\" id=\"director\" value=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->getAttribute(($context["film"] ?? $this->getContext($context, "film")), "director", array()), "html", null, true);
        echo "\" name=\"film[director]\" />
                <label for=\"year\">Year</label>
                <input type=\"text\" id=\"year\" value=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->getAttribute(($context["film"] ?? $this->getContext($context, "film")), "year", array()), "html", null, true);
        echo "\" name=\"film[year]\" />

                ";
        // line 17
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "_token", array()), 'row');
        echo "

                <button type=\"submit\" class=\"accept\">Edit</button>
                <button type=\"button\" onclick=\"location.href='/'\" class=\"cancel\">Cancel</button>
            </div>
        </form>
    </section>
";
        
        $__internal_647109de8645dba3d740e006229c10b9b5577311187bf4317e925d88989b29ca->leave($__internal_647109de8645dba3d740e006229c10b9b5577311187bf4317e925d88989b29ca_prof);

        
        $__internal_b3f94bc7f3afa5406f35607378f931df73ea65dfcc415b52cb68ffdcd2f5a57c->leave($__internal_b3f94bc7f3afa5406f35607378f931df73ea65dfcc415b52cb68ffdcd2f5a57c_prof);

    }

    public function getTemplateName()
    {
        return "film/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  76 => 17,  71 => 15,  66 => 13,  61 => 11,  56 => 9,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block main %}
    <h1>Edit Film</h1>
    <section>
        <form method=\"POST\">
            <div>
                <label for=\"name\">Name</label>
                <input type=\"text\" id=\"name\" value=\"{{ film.name }}\" name=\"film[name]\" />
                <label for=\"genre\">Genre</label>
                <input type=\"text\" id=\"genre\" value=\"{{ film.genre }}\" name=\"film[genre]\" />
                <label for=\"director\">Director</label>
                <input type=\"text\" id=\"director\" value=\"{{ film.director }}\" name=\"film[director]\" />
                <label for=\"year\">Year</label>
                <input type=\"text\" id=\"year\" value=\"{{ film.year }}\" name=\"film[year]\" />

                {{ form_row(form._token) }}

                <button type=\"submit\" class=\"accept\">Edit</button>
                <button type=\"button\" onclick=\"location.href='/'\" class=\"cancel\">Cancel</button>
            </div>
        </form>
    </section>
{% endblock %}", "film/edit.html.twig", "F:\\00. Work\\Software-Technologies-Exam-Prep-III\\Solutions\\PHP Skeleton\\app\\Resources\\views\\film\\edit.html.twig");
    }
}
